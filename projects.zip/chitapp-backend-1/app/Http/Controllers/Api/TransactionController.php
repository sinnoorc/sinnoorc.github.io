<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\Customer;
use App\Models\Transaction;
use Illuminate\Http\Request;

class TransactionController extends Controller
{

    public function index($month)
    {
        try {
            if ($month == 'all') {
                $transactions = Transaction::all()->sortByDesc('created_at')->values()->all();

            } else {
                $transactions = Transaction::whereMonth('created_at', $month)->orderBy('created_at', 'desc')->get();
            }
            foreach ($transactions as $transaction) {
                $customer = Customer::where('id', $transaction->customer_id)->first();
                $name = $customer->name;
                $phone = $customer->phone;
                $customer = [
                    'name' => $name,
                    'phone' => $phone,
                ];
                $transaction->customer = $customer;
            }

            return response()->json([
                'transactions' => $transactions,
            ], 200);
        } catch (\Exception$e) {
            return response()->json([
                'message' => 'Transactions could not be retrieved',
                'error' => $e->getMessage(),
            ], 500);
        }
    }

    public function store(Request $request)
    {
        try {
            $customer = Customer::where('id', $request->customer_id)->first();
            $transactions = Transaction::whereMonth('created_at', date('m'))->get();
            foreach ($transactions as $transaction) {
                if ($transaction->customer_id == $customer->id) {
                    return response()->json([
                        'message' => 'Transaction is already created for this month',
                    ], 409);
                }
            }

            $request->validate([
                'customer_id' => 'required',
                'amount' => 'required',
            ]);
            $transaction = Transaction::create($request->all());
            return response()->json([
                'transaction' => $transaction,
            ], 200);
        } catch (\Exception$e) {
            return response()->json([
                'error' => $e->getMessage(),
            ], 409);
        }
    }

    public function show($id)
    {
        try {
            $transaction = Transaction::findOrFail($id);
            $customer = Customer::findOrFail($transaction->customer_id);
            return response()->json([
                'transaction' => $transaction,
                'customer' => $customer,
            ], 200);
        } catch (\Exception$e) {
            return response()->json([
                'message' => 'Transaction could not be retrieved',
                'error' => $e->getMessage(),
            ], 500);
        }
    }

    public function markAsSelected(Transaction $transaction)
    {

        try {
            $transactions = Transaction::whereMonth('created_at', date('m'))->get();
            foreach ($transactions as $transaction) {
                $transaction->is_selected = 0;
                $transaction->save();
            }
            $transaction->is_selected = 1;
            $transaction->save();
            return response()->json([
                'message' => 'Transaction marked as selected',
            ], 200);
        } catch (\Exception$e) {
            return response()->json([
                'message' => 'Transaction could not be marked as selected',
                'error' => $e->getMessage(),
            ], 500);
        }
    }

    public function getSelectedTransactions()
    {
        try {
            $transactions = Transaction::where('is_selected', true)->get();
            foreach ($transactions as $transaction) {
                $customer = Customer::where('id', $transaction->customer_id)->first();
                $name = $customer->name;
                $phone = $customer->phone;
                $customer = [
                    'name' => $name,
                    'phone' => $phone,
                ];
                $transaction->customer = $customer;
            }
            return response()->json([
                'transactions' => $transactions,
            ], 200);
        } catch (\Exception$e) {
            return response()->json([
                'message' => 'Transactions could not be retrieved',
                'error' => $e->getMessage(),
            ], 500);
        }
    }

}
