<?php

use App\Http\Controllers\Api\CoordinatorController;
use App\Http\Controllers\Api\CustomerController;
use App\Http\Controllers\Api\HomeController;
use App\Http\Controllers\Api\LoginController;
use App\Http\Controllers\Api\TransactionController;
use Illuminate\Support\Facades\Route;

Route::post('/login', [LoginController::class, 'login']);
Route::post('/register', [LoginController::class, 'register']);

Route::middleware('auth:api')->group(function () {
    Route::post('/logout', [LoginController::class, 'logout']);

    //! Coordinators
    Route::get('/coordinators', [CoordinatorController::class, 'index']);
    Route::post('/coordinators', [CoordinatorController::class, 'store']);
    Route::get('/coordinators/{id}', [CoordinatorController::class, 'show']);
    Route::put('/coordinators/{id}', [CoordinatorController::class, 'update']);
    Route::delete('/coordinators/{id}', [CoordinatorController::class, 'destroy']);

    //! Customers
    Route::get('/customers', [CustomerController::class, 'index']);
    Route::post('/customers', [CustomerController::class, 'store']);
    Route::get('/customers/{id}', [CustomerController::class, 'show']);
    Route::put('/customers/{id}', [CustomerController::class, 'update']);
    Route::delete('/customers/{id}', [CustomerController::class, 'destroy']);

    //! Transactions
    Route::get('/transactions/{month}', [TransactionController::class, 'index']);
    Route::post('/transactions', [TransactionController::class, 'store']);
    Route::get('/transactions/{id}', [TransactionController::class, 'show']);
    Route::post('/mark-transaction', [TransactionController::class, 'markAsSelected']);
    Route::get('/selected-transactions', [TransactionController::class, 'getSelectedTransactions']);
    Route::get('/customer-transactions/{id}', [TransactionController::class, 'getTransactionByCustomerId']);

    //! Home
    Route::get('/home', [HomeController::class, 'index']);

});
